import fachada from "../assets/fachada.jpg";
import redVelvet from "../assets/red-velvet.jpg";
import letreiro from "../assets/letreiro.jpg";
import mesaDoces from "../assets/mesa-doces.jpg";

// Galeria. A seção só aparece com 3 ou mais fotos reais.
// area (a, b, c, d) define o lugar no desktop; pos ajusta o enquadramento do recorte.
export const gallery = [
  { id: "g1", src: fachada, alt: "Fachada da Quitanderia Gourmet, com cerca de madeira e letreiro", area: "a", pos: "50% 35%" },
  { id: "g2", src: redVelvet, alt: "Bolo red velvet em um suporte, cercado de doces", area: "b" },
  { id: "g3", src: letreiro, alt: "Letreiro da Quitanderia Gourmet na parede de pedra", area: "c", pos: "50% 45%" },
  { id: "g4", src: mesaDoces, alt: "Mesa com bolos e tortas em suportes e travessas", area: "d" },
];

export const galleryVisible = gallery.length >= 3;
