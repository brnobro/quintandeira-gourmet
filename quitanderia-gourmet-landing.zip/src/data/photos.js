import salao from "../assets/salao.jpg";
import salgados from "../assets/cafe-colonial-salgados.jpg";

// Fotos das seções "Sobre" e "Café Colonial". As outras quatro fotos estão em data/gallery.js.
// width e height são o tamanho do arquivo: reservam o espaço e evitam salto no carregamento.
export const photos = {
  intro: {
    src: salao,
    alt: "Salão da Quitanderia Gourmet: mesa de madeira cheia de bolos e tortas e pratos pendurados na parede",
    width: 411,
    height: 486,
  },
  colonial: {
    src: salgados,
    alt: "Mesa do café colonial com travessas de salgados e pães",
    width: 399,
    height: 501,
  },
};
