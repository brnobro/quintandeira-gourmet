// Dados do negócio. Edite aqui sem mexer nos componentes.
// Campo vazio ("") = o elemento correspondente não aparece na página.
export const business = {
  name: "Quitanderia Gourmet",
  addressLine1: "Av. Cesário Alvim, 969",
  addressLine2: "Centro — Uberlândia/MG",

  // Só dígitos, com DDI e DDD. Ex.: "5534999999999"
  whatsapp: "553425895754",
  whatsappMessage: "Olá! Vi o site da Quitanderia Gourmet e gostaria de saber mais.",

  instagram: "https://www.instagram.com/quitanderiagourmet/",
  facebook: "https://www.facebook.com/quitanderiagourmet/",

  // Cole aqui o link do perfil no Google Maps (Compartilhar > Copiar link).
  // Vazio: o botão "Como chegar" abre uma busca pelo endereço.
  maps: "",
  // Link do perfil para ver as avaliações. Vazio: usa o link do Maps.
  googleReviews: "",

  // Horário informado no Instagram. Confirmar com o cliente se vale para a loja toda
  // ou só para o Café Colonial.
  hours: { days: "Segunda a sábado", time: "08:30 — 19:30", note: "Café Colonial" },
};

const searchQuery = `${business.name} ${business.addressLine1} Uberlândia MG`;

export const mapsUrl = () =>
  business.maps || `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(searchQuery)}`;

export const mapsEmbedUrl = () => `https://www.google.com/maps?q=${encodeURIComponent(searchQuery)}&output=embed`;

export const reviewsUrl = () => business.googleReviews || mapsUrl();

export const whatsappUrl = () =>
  business.whatsapp ? `https://wa.me/${business.whatsapp}?text=${encodeURIComponent(business.whatsappMessage)}` : "";
