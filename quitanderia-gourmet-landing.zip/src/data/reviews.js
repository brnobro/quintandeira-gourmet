// Avaliações REAIS do Google Maps, inseridas manualmente.
// Formato: { name: "Nome da pessoa", stars: 5, text: "Comentário real" }
// Enquanto a lista estiver vazia, a seção mostra um convite para ver no Google.
export const reviews = [];
