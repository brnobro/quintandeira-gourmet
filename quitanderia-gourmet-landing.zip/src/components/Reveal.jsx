import { m, useReducedMotion } from "framer-motion";

// Entrada suave, usada só em três pontos da página (intro, café colonial, chamada final).
export default function Reveal({ children, delay = 0, className }) {
  const reduce = useReducedMotion();
  return (
    <m.div
      className={className}
      initial={reduce ? false : { opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "0px 0px -10% 0px" }}
      transition={{ duration: 0.9, delay, ease: [0.22, 0.8, 0.24, 1] }}
    >
      {children}
    </m.div>
  );
}
