import { useRef } from "react";
import { m, useScroll, useTransform, useReducedMotion } from "framer-motion";

// Linha dourada que se abre atravessando a tela, entre o hero e a primeira seção.
export default function GoldLine() {
  const ref = useRef(null);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 95%", "start 60%"] });
  const scaleX = useTransform(scrollYProgress, [0, 1], [0.05, 1]);

  return (
    <div className="goldline-wrap" ref={ref} aria-hidden="true">
      <m.div className="goldline" style={reduce ? undefined : { scaleX }} />
    </div>
  );
}
