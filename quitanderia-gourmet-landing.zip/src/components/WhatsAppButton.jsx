import WhatsAppIcon from "./WhatsAppIcon.jsx";
import { whatsappUrl } from "../data/business.js";

// Botão flutuante. Sem número configurado, não aparece (nada de botão sem ação).
export default function WhatsAppButton() {
  const url = whatsappUrl();
  if (!url) return null;
  return (
    <a className="wa-float" href={url} target="_blank" rel="noopener noreferrer" aria-label="Falar no WhatsApp">
      <WhatsAppIcon />
      <span className="wa-text">Fale conosco</span>
    </a>
  );
}
