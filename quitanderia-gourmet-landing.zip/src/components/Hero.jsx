import { useRef } from "react";
import { m, useScroll, useTransform, useMotionValueEvent, useReducedMotion } from "framer-motion";
import GlazeCanvas from "./GlazeCanvas.jsx";

const ease = [0.22, 0.8, 0.24, 1];
const rise = (delay, y = 28) => ({
  initial: { opacity: 0, y },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 1, delay, ease },
});

export default function Hero() {
  const track = useRef(null);
  const glazeProgress = useRef(0);
  const reduce = useReducedMotion();
  const { scrollYProgress } = useScroll({ target: track, offset: ["start start", "end end"] });

  // A calda escorre durante a primeira parte do scroll; depois a foto encolhe.
  useMotionValueEvent(scrollYProgress, "change", (v) => {
    glazeProgress.current = clamp01((v - 0.04) / 0.62);
  });

  const scale = useTransform(scrollYProgress, [0.55, 1], [1, 0.92]);
  const radius = useTransform(scrollYProgress, [0.55, 1], [0, 48]);
  const contentOpacity = useTransform(scrollYProgress, [0.5, 0.85], [1, 0]);

  return (
    <section id="inicio" className="hero-track" ref={track}>
      <m.div className="hero-sticky" style={reduce ? undefined : { scale, borderRadius: radius }}>
        <m.div
          className="hero-media"
          initial={reduce ? false : { scale: 1.08 }}
          animate={{ scale: 1 }}
          transition={{ duration: 2.6, ease }}
        >
          <GlazeCanvas progressRef={glazeProgress} label="Bolo com cobertura de chocolate sobre mesa de veludo bordô" />
        </m.div>
        <div className="hero-overlay" />

        <m.div className="container hero-content" style={reduce ? undefined : { opacity: contentOpacity }}>
          <m.h1 {...(reduce ? {} : rise(0.5, 36))}>
            <span className="sr-only">Quitanderia Gourmet: </span>
            Café, bolo e <em>mesa posta.</em>
          </m.h1>
          <m.p className="hero-sub" {...(reduce ? {} : rise(0.8))}>
            Cafeteria, confeitaria e café colonial no Centro de Uberlândia.
          </m.p>
          <m.div className="hero-cta" {...(reduce ? {} : rise(1))}>
            <a className="btn btn-gold" href="#sobre">
              Conhecer a casa
            </a>
            <a className="btn btn-ghost" href="#cardapio">
              Cardápio
            </a>
          </m.div>
        </m.div>
      </m.div>
    </section>
  );
}

function clamp01(v) {
  return Math.min(1, Math.max(0, v));
}
