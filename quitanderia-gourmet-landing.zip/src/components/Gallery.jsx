import { useEffect, useRef, useState } from "react";
import { AnimatePresence, m } from "framer-motion";
import { gallery, galleryVisible } from "../data/gallery.js";

export default function Gallery() {
  const [open, setOpen] = useState(null);
  const closeRef = useRef(null);
  const opener = useRef(null);

  useEffect(() => {
    if (!open) return;
    closeRef.current?.focus();
    const onKey = (e) => e.key === "Escape" && close();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  if (!galleryVisible) return null;

  function show(g, e) {
    opener.current = e.currentTarget;
    setOpen(g);
  }
  function close() {
    setOpen(null);
    opener.current?.focus();
  }

  return (
    <section id="galeria" className="section gallery" aria-labelledby="gallery-title">
      <div className="container">
        <p className="eyebrow">Galeria</p>
        <h2 id="gallery-title" className="title">
          A casa <em>em fotos.</em>
        </h2>
        <div className="g-track">
          {gallery.map((g) => (
            <button key={g.id} type="button" className={`g-item ${g.area || ""}`} onClick={(e) => show(g, e)} aria-label={`Ampliar: ${g.alt}`}>
              <img src={g.src} alt={g.alt} loading="lazy" style={g.pos ? { objectPosition: g.pos } : undefined} />
            </button>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {open && (
          <m.div
            className="lightbox"
            role="dialog"
            aria-modal="true"
            aria-label={open.alt}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={close}
          >
            <button ref={closeRef} type="button" className="lightbox-close" aria-label="Fechar" onClick={close}>
              ✕
            </button>
            <img src={open.src} alt={open.alt} onClick={(e) => e.stopPropagation()} />
          </m.div>
        )}
      </AnimatePresence>
    </section>
  );
}
