import { business, mapsUrl, mapsEmbedUrl, reviewsUrl } from "../data/business.js";
import { reviews } from "../data/reviews.js";

const embed = import.meta.env.VITE_EMBED_MAP !== "0";

export default function Location() {
  const { hours } = business;
  return (
    <section id="localizacao" className="section location" aria-labelledby="loc-title">
      <div className="container loc-grid">
        <div>
          <p className="eyebrow">Localização</p>
          <h2 id="loc-title" className="title">
            Onde <em>estamos.</em>
          </h2>

          <address className="loc-addr">
            <strong>{business.name}</strong>
            {business.addressLine1}
            <br />
            {business.addressLine2}
          </address>

          <dl className="hours">
            <dt>{hours.days}</dt>
            <dd>
              {hours.time}
              {hours.note && <small>{hours.note}</small>}
            </dd>
          </dl>

          <div className="loc-actions">
            <a className="btn btn-bordeaux" href={mapsUrl()} target="_blank" rel="noopener noreferrer">
              Como chegar
            </a>
            {/* Só aparece quando há um link de avaliações diferente do Maps (data/business.js). */}
            {business.googleReviews && !reviews.length && (
              <a className="text-link" href={reviewsUrl()} target="_blank" rel="noopener noreferrer">
                Ver avaliações no Google
              </a>
            )}
          </div>
        </div>

        <div className="map">
          {/* Reserva para quando o mapa não carrega; com o mapa ativo fica fora da navegação por teclado. */}
          <a
            className="map-fallback"
            href={mapsUrl()}
            target="_blank"
            rel="noopener noreferrer"
            {...(embed ? { tabIndex: -1, "aria-hidden": "true" } : {})}
          >
            Abrir no Google Maps
          </a>
          {embed && (
            <iframe
              title="Mapa com a localização da Quitanderia Gourmet"
              src={mapsEmbedUrl()}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          )}
        </div>
      </div>
    </section>
  );
}
