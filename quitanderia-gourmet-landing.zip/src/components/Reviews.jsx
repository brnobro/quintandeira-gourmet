import { reviews } from "../data/reviews.js";
import { reviewsUrl } from "../data/business.js";

// Só aparece com avaliações reais cadastradas em data/reviews.js.
export default function Reviews() {
  if (!reviews.length) return null;
  return (
    <section id="avaliacoes" className="section reviews" aria-labelledby="reviews-title">
      <div className="container">
        <p className="eyebrow">Avaliações</p>
        <h2 id="reviews-title" className="title">
          Quem passa por aqui, <em>conta.</em>
        </h2>
        <ul className="r-list">
          {reviews.map((r, i) => (
            <li className="r-item" key={i}>
              <p className="stars" aria-label={`${r.stars} de 5 estrelas`}>
                {"★".repeat(r.stars)}
              </p>
              <blockquote>“{r.text}”</blockquote>
              <cite>{r.name}</cite>
            </li>
          ))}
        </ul>
        <a className="text-link" href={reviewsUrl()} target="_blank" rel="noopener noreferrer">
          Ver no Google
        </a>
      </div>
    </section>
  );
}
