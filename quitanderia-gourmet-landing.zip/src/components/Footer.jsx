import logo from "../assets/logo-cream.png";
import { business, mapsUrl } from "../data/business.js";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <img className="f-logo" src={logo} alt="Quitanderia Gourmet" width="140" height="58" loading="lazy" />
        <p className="f-addr">
          {business.addressLine1}, {business.addressLine2}
        </p>
        <ul className="f-links">
          <li>
            <a href={business.instagram} target="_blank" rel="noopener noreferrer">
              Instagram
            </a>
          </li>
          {business.facebook && (
            <li>
              <a href={business.facebook} target="_blank" rel="noopener noreferrer">
                Facebook
              </a>
            </li>
          )}
          <li>
            <a href={mapsUrl()} target="_blank" rel="noopener noreferrer">
              Google Maps
            </a>
          </li>
          <li>
            <a href="#cardapio">Cardápio</a>
          </li>
        </ul>
      </div>
      <div className="container copy">
        <span>© 2026 Quitanderia Gourmet</span>
        <a href="#inicio">Voltar ao topo</a>
      </div>
    </footer>
  );
}
