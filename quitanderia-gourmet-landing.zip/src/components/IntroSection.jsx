import Reveal from "./Reveal.jsx";
import { photos } from "../data/photos.js";

// Apresentação da casa: texto curto e uma foto do salão.
export default function IntroSection() {
  const photo = photos.intro;
  return (
    <section id="sobre" className="section intro" aria-labelledby="intro-title">
      <div className="container intro-grid">
        <Reveal>
          <p className="eyebrow">Sobre</p>
          <h2 id="intro-title" className="title">
            Café com cara de <em>casa.</em>
          </h2>
          <p className="lead">Madeira, pratos na parede e lugar para ficar um pouco mais.</p>
        </Reveal>
        {photo && (
          <Reveal delay={0.1} className="intro-photo">
            <img src={photo.src} alt={photo.alt} width={photo.width} height={photo.height} loading="lazy" />
          </Reveal>
        )}
      </div>
    </section>
  );
}
