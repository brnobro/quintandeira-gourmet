import Reveal from "./Reveal.jsx";
import selo from "../assets/selo.png";
import { business } from "../data/business.js";

// Chamada final: redes sociais da casa (o WhatsApp fica só no botão flutuante).
export default function CTA() {
  return (
    <section className="cta" aria-labelledby="cta-title">
      <div className="container cta-grid">
        <Reveal>
          <h2 id="cta-title" className="title light">
            Seu próximo café <em>pode ser aqui.</em>
          </h2>
          <div className="cta-btns">
            <a className="btn btn-gold" href={business.instagram} target="_blank" rel="noopener noreferrer">
              Instagram
            </a>
            {business.facebook && (
              <a className="btn btn-ghost" href={business.facebook} target="_blank" rel="noopener noreferrer">
                Facebook
              </a>
            )}
          </div>
        </Reveal>
        <img className="cta-seal" src={selo} alt="" width="150" height="150" loading="lazy" />
      </div>
    </section>
  );
}
