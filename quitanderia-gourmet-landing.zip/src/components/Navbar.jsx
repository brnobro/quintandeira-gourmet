import { useEffect, useState } from "react";
import { AnimatePresence, m } from "framer-motion";
import logo from "../assets/logo-cream.png";
import { reviews } from "../data/reviews.js";
import { galleryVisible } from "../data/gallery.js";

const links = [
  { href: "#inicio", label: "Início" },
  { href: "#sobre", label: "Sobre" },
  { href: "#cafe-colonial", label: "Café Colonial" },
  ...(galleryVisible ? [{ href: "#galeria", label: "Galeria" }] : []),
  ...(reviews.length ? [{ href: "#avaliacoes", label: "Avaliações" }] : []),
  { href: "#localizacao", label: "Localização" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <>
      <header className={`nav ${scrolled || open ? "scrolled" : ""}`}>
        <div className="container nav-inner">
          <a href="#inicio" className="nav-logo" aria-label="Quitanderia Gourmet, início" onClick={() => setOpen(false)}>
            <img src={logo} alt="" width="140" height="58" />
          </a>
          <nav className="nav-links" aria-label="Principal">
            {links.map((l) => (
              <a key={l.href} href={l.href}>
                {l.label}
              </a>
            ))}
          </nav>
          <div className="nav-actions">
            <button
              className={`burger ${open ? "open" : ""}`}
              aria-label={open ? "Fechar menu" : "Abrir menu"}
              aria-expanded={open}
              aria-controls="menu-mobile"
              onClick={() => setOpen((v) => !v)}
            >
              <span />
              <span />
            </button>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <m.div
            id="menu-mobile"
            className="mobile-menu"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            {links.map((l) => (
              <a key={l.href} className="m-link" href={l.href} onClick={() => setOpen(false)}>
                {l.label}
              </a>
            ))}
          </m.div>
        )}
      </AnimatePresence>
    </>
  );
}
