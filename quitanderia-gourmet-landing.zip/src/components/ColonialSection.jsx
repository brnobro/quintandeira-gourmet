import Reveal from "./Reveal.jsx";
import { photos } from "../data/photos.js";
import { galleryVisible } from "../data/gallery.js";

// Texto à esquerda e a foto da mesa à direita, sobre bordô.
export default function ColonialSection() {
  const photo = photos.colonial;
  return (
    <section id="cafe-colonial" className="colonial" aria-labelledby="colonial-title">
      <div className="container colonial-grid">
        <Reveal>
          <p className="eyebrow">Café Colonial</p>
          <h2 id="colonial-title" className="title light">
            Nosso <em>Café Colonial</em>
          </h2>
          <p className="lead">Uma mesa farta de quitandas, doces e café.</p>
          {galleryVisible && (
            <a className="btn btn-gold" href="#galeria">
              Ver fotos
            </a>
          )}
        </Reveal>
        {photo && (
          <Reveal delay={0.1} className="colonial-photo">
            <img src={photo.src} alt={photo.alt} width={photo.width} height={photo.height} loading="lazy" />
          </Reveal>
        )}
      </div>
    </section>
  );
}
