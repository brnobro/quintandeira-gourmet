import { menu } from "../data/menu.js";

// Cardápio simples: três blocos recolhidos, sem imagens. Os dados ficam em data/menu.js.
export default function MenuSection() {
  return (
    <section id="cardapio" className="menu" aria-labelledby="menu-title">
      <div className="container">
        <h2 id="menu-title" className="menu-title">
          Cardápio
        </h2>
        <div className="menu-cats">
          {menu.map((cat) => (
            <details key={cat.id} className="menu-cat">
              <summary>{cat.title}</summary>
              {cat.note && <p className="menu-note">{cat.note}</p>}
              <ul className="menu-list">
                {cat.items.map((item, i) => (
                  <li className="menu-item" key={`${item.name}-${i}`}>
                    <div className="mi-head">
                      <span>{item.name}</span>
                      <span className="mi-price">{item.price}</span>
                    </div>
                    {item.desc && <p className="mi-desc">{item.desc}</p>}
                    {item.list && (
                      <p className="mi-desc">
                        {item.listLabel && <strong>{item.listLabel}: </strong>}
                        {item.list.join(", ")}
                      </p>
                    )}
                  </li>
                ))}
              </ul>
            </details>
          ))}
        </div>
      </div>
    </section>
  );
}
