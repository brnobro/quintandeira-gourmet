import { useEffect, useRef } from "react";
import { useReducedMotion } from "framer-motion";
import bolo from "../assets/bolo.jpg";
import { glaze } from "../data/glaze.js";

// A imagem começa a baixar assim que o módulo carrega.
const img = new Image();
img.decoding = "async";
img.src = bolo;

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));

// Desenha o bolo (object-fit: cover) e, conforme `progress` (0 a 1), estica só as
// faixas de calda de cada gota para baixo. O resto da foto não se move.
function paint(ctx, W, H, pos, progress, step) {
  const iw = img.naturalWidth;
  const ih = img.naturalHeight;
  const s = Math.max(W / iw, H / ih);
  const ox = (W - iw * s) * pos.x;
  const oy = (H - ih * s) * pos.y;

  ctx.clearRect(0, 0, W, H);
  ctx.drawImage(img, ox, oy, iw * s, ih * s);
  if (progress < 0.004) return;

  const { x0, tip, base, band, groups } = glaze;
  for (const g of groups) {
    for (let x = g.a; x < g.b; x += step) {
      const t = tip[x - x0];
      if (!(t > 0)) continue;
      const w = Math.pow(clamp((t - base) / (g.tm - base)), 1.3);
      const ext = g.reach * progress * w;
      if (ext < 0.4) continue;
      const ys = t - band;
      ctx.drawImage(
        img,
        x, ys, step, band,
        ox + x * s, oy + ys * s, step * s + 0.8, (band + ext) * s
      );
    }
  }
}

export default function GlazeCanvas({ progressRef, label }) {
  const canvasRef = useRef(null);
  const reduce = useReducedMotion();

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    const state = { W: 0, H: 0, dpr: 1, cur: 0, raf: 0, ready: false };

    const small = () => window.innerWidth < 700;
    const pos = () => (small() ? { x: 0.72, y: 0.5 } : { x: 0.8, y: 0.5 });

    const render = () => {
      if (!state.ready) return;
      ctx.setTransform(state.dpr, 0, 0, state.dpr, 0, 0);
      paint(ctx, state.W, state.H, pos(), state.cur, small() ? 2 : 1);
    };

    const tick = () => {
      state.raf = 0;
      const target = reduce ? 0 : progressRef.current;
      // A calda acompanha o scroll com um pouco de atraso: parece espessa.
      state.cur += (target - state.cur) * 0.11;
      if (Math.abs(target - state.cur) < 0.002) state.cur = target;
      render();
      if (state.cur !== target) state.raf = requestAnimationFrame(tick);
    };
    const request = () => {
      if (!state.raf) state.raf = requestAnimationFrame(tick);
    };

    const resize = () => {
      const r = canvas.parentElement.getBoundingClientRect();
      state.dpr = Math.min(window.devicePixelRatio || 1, small() ? 1.5 : 2);
      state.W = r.width;
      state.H = r.height;
      canvas.width = Math.round(r.width * state.dpr);
      canvas.height = Math.round(r.height * state.dpr);
      render();
    };

    const start = () => {
      state.ready = true;
      state.cur = reduce ? 0 : progressRef.current;
      resize();
    };
    if (img.complete && img.naturalWidth) start();
    else img.addEventListener("load", start, { once: true });

    const ro = new ResizeObserver(resize);
    ro.observe(canvas.parentElement);
    window.addEventListener("scroll", request, { passive: true });

    return () => {
      ro.disconnect();
      window.removeEventListener("scroll", request);
      img.removeEventListener("load", start);
      cancelAnimationFrame(state.raf);
    };
  }, [progressRef, reduce]);

  return <canvas ref={canvasRef} className="glaze-canvas" role="img" aria-label={label} />;
}
