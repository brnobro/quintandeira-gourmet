import { LazyMotion, domAnimation } from "framer-motion";
import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import GoldLine from "./components/GoldLine.jsx";
import IntroSection from "./components/IntroSection.jsx";
import ColonialSection from "./components/ColonialSection.jsx";
import Gallery from "./components/Gallery.jsx";
import Reviews from "./components/Reviews.jsx";
import Location from "./components/Location.jsx";
import MenuSection from "./components/MenuSection.jsx";
import CTA from "./components/CTA.jsx";
import Footer from "./components/Footer.jsx";
import WhatsAppButton from "./components/WhatsAppButton.jsx";

export default function App() {
  return (
    <LazyMotion features={domAnimation} strict>
      <a className="skip" href="#conteudo">
        Pular para o conteúdo
      </a>
      <Navbar />
      <main id="conteudo">
        <Hero />
        <GoldLine />
        <IntroSection />
        <ColonialSection />
        <Gallery />
        <Reviews />
        <Location />
        <MenuSection />
        <CTA />
      </main>
      <Footer />
      <WhatsAppButton />
    </LazyMotion>
  );
}
